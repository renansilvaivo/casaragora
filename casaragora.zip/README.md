# CasaAgora - Template de Site de Casamento

Arquivos prontos para personalização. Substitua imagens em `img/` e ajuste textos.

- Abra `index.html` localmente para ver o site.
- Para produzir QR Codes PIX reais, gere o payload BRCode no servidor.

## Deploy rápido
```bash
git init
git add .
git commit -m "Versão inicial CasaAgora"
git remote add origin https://github.com/SEU_USUARIO/casaragora.git
git push -u origin master
```
